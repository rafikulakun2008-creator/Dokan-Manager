# Dokan Manager — GitHub Cloud Build package

এই repository-টি GitHub Actions ব্যবহার করে Cloud-এ Android APK তৈরি করবে। আপনার Windows কম্পিউটারে Android Studio/Flutter ইনস্টল করা বাধ্যতামূলক নয়।

## GitHub-এ আপলোড
1. GitHub-এ লগইন করে **New repository** নির্বাচন করুন।
2. Repository name দিন `Dokan-Manager`।
3. Public বা Private যেকোনোটি নির্বাচন করে repository তৈরি করুন।
4. এই ZIP Extract করে ভেতরের ফাইলগুলো repository-র root-এ আপলোড করুন। ZIP ফাইলটিকে ZIP হিসেবেই repository-তে রাখবেন না।
5. `Commit changes` করুন।

## APK কোথায় পাবেন?
- Repository → **Actions** → `Build Dokan Manager APK` → সর্বশেষ সফল workflow run → নিচে **Artifacts** → `dokan-manager-apk` ডাউনলোড করুন।
- GitHub-এর **Releases**-এ APK প্রকাশ করতে repository-র **Releases** → **Create a new release** খুলুন, tag হিসেবে `v1.0.0` দিন এবং Publish করুন। Tag push হলে workflow APK build করে ওই Release-এ সংযুক্ত করবে।
- পরবর্তী সংস্করণের জন্য নতুন tag ব্যবহার করুন, যেমন `v1.0.1`, `v1.0.2`।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
এটি একটি প্রাথমিক offline-first MVP starter, সম্পূর্ণ production-ready POS নয়। বর্তমান সংস্করণে পণ্য, ক্রেতা, খরচ ও সাধারণ বিক্রির প্রাথমিক ফিচার আছে। বিক্রির সময় পণ্য-স্টক কমে। তবে একাধিক পণ্যসহ invoice, customer-linked credit sales/payment collection, data backup/restore, edit/delete, receipt printing, low-stock notification, AdMob এবং signed Play Store release এখনো যোগ করা হয়নি। Dashboard-এর estimated balance হলো মোট বিক্রি minus মোট খরচ; এটি পূর্ণ accounting profit নয়।

ডেটা ফোনের স্থানীয় SQLite ডেটাবেজে থাকে। অ্যাপ আনইনস্টল বা ফোন নষ্ট হলে ডেটা হারাতে পারে। গুরুত্বপূর্ণ হিসাবের জন্য এখনই একমাত্র কপি হিসেবে ব্যবহার করবেন না।

## বিজ্ঞাপন ও Play Store
AdMob এই starter-এ সক্রিয় নয়। বিজ্ঞাপন যোগ করার আগে AdMob account, app registration, policy compliance এবং test ads দিয়ে পরীক্ষা প্রয়োজন। Play Store release-এর জন্য আলাদা upload keystore ও signing configuration লাগবে; এই workflow unsigned APK তৈরি করে।
