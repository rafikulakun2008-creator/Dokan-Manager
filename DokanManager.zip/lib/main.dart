import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ShopDb.instance.database;
  runApp(const DokanApp());
}

class ShopDb {
  ShopDb._();
  static final instance = ShopDb._();
  Database? _db;
  Future<Database> get database async {
    if (_db != null) return _db!;
    final base = await getDatabasesPath();
    _db = await openDatabase(p.join(base, 'dokan_manager.db'),
      version: 1, onCreate: (db, version) async {
        await db.execute('CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, price REAL NOT NULL, stock INTEGER NOT NULL DEFAULT 0)');
        await db.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT, due REAL NOT NULL DEFAULT 0)');
        await db.execute('CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, amount REAL NOT NULL, created_at TEXT NOT NULL)');
        await db.execute('CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, total REAL NOT NULL, paid REAL NOT NULL, created_at TEXT NOT NULL)');
      });
    return _db!;
  }
  Future<int> add(String table, Map<String,Object?> row) async => (await database).insert(table, row);
  Future<List<Map<String,Object?>>> rows(String table) async => (await database).query(table, orderBy: 'id DESC');
  Future<double> sum(String table, String column) async {
    final r = await (await database).rawQuery('SELECT COALESCE(SUM($column),0) AS total FROM $table');
    return (r.first['total'] as num).toDouble();
  }
}

class DokanApp extends StatefulWidget {
  const DokanApp({super.key});
  @override State<DokanApp> createState() => _DokanAppState();
}
class _DokanAppState extends State<DokanApp> {
  bool english = false;
  @override void initState() { super.initState(); _loadLanguage(); }
  Future<void> _loadLanguage() async {
    final p = await SharedPreferences.getInstance();
    setState(() => english = p.getBool('english') ?? false);
  }
  Future<void> toggle() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('english', !english);
    setState(() => english = !english);
  }
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Dokan Manager',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF137A52)), useMaterial3: true),
    home: HomePage(english: english, onLanguage: toggle),
  );
}

class HomePage extends StatefulWidget {
  final bool english; final VoidCallback onLanguage;
  const HomePage({super.key, required this.english, required this.onLanguage});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int tab = 0;
  String t(String bn, String en) => widget.english ? en : bn;
  String money(num n) => '৳${NumberFormat('#,##0.##').format(n)}';
  Future<void> refresh() async { if (mounted) setState(() {}); }
  Future<void> addDialog(String title, List<String> labels, Future<void> Function(List<String>) save) async {
    final ctrls = labels.map((_) => TextEditingController()).toList();
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: Text(title), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        for (int i=0;i<labels.length;i++) Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: ctrls[i], keyboardType: i>0 ? const TextInputType.numberWithOptions(decimal:true) : TextInputType.text, decoration: InputDecoration(labelText: labels[i], border: const OutlineInputBorder()))),
      ])),
      actions: [TextButton(onPressed: ()=>Navigator.pop(ctx), child: Text(t('বাতিল','Cancel'))),
        FilledButton(onPressed: () async { final values=ctrls.map((c)=>c.text.trim()).toList(); if(values.any((v)=>v.isEmpty)){return;} await save(values); if(ctx.mounted) Navigator.pop(ctx); await refresh(); }, child: Text(t('সংরক্ষণ','Save')))]
    ));
    for(final c in ctrls){c.dispose();}
  }
  Future<void> addProduct() => addDialog(t('নতুন পণ্য','New product'), [t('পণ্যের নাম','Product name'),t('দাম','Price'),t('স্টক','Stock')], (v) async {
    await ShopDb.instance.add('products', {'name':v[0], 'price':double.tryParse(v[1])??0, 'stock':int.tryParse(v[2])??0});
  });
  Future<void> addCustomer() => addDialog(t('নতুন ক্রেতা','New customer'), [t('ক্রেতার নাম','Customer name'),t('ফোন নম্বর','Phone number'),t('বাকি টাকা','Opening due')], (v) async {
    await ShopDb.instance.add('customers', {'name':v[0], 'phone':v[1], 'due':double.tryParse(v[2])??0});
  });
  Future<void> addExpense() => addDialog(t('নতুন খরচ','New expense'), [t('খরচের বিবরণ','Expense title'),t('টাকার পরিমাণ','Amount')], (v) async {
    await ShopDb.instance.add('expenses', {'title':v[0], 'amount':double.tryParse(v[1])??0, 'created_at':DateTime.now().toIso8601String()});
  });
  Future<void> addSale() async {
    final products=await ShopDb.instance.rows('products');
    if(products.isEmpty){ if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(t('আগে একটি পণ্য যোগ করুন','Add a product first')))); return; }
    int selected=(products.first['id'] as int); final qty=TextEditingController(text:'1');
    await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setLocal)=>AlertDialog(
      title:Text(t('নতুন বিক্রি','New sale')),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButton<int>(isExpanded:true,value:selected,items:products.map((p)=>DropdownMenuItem(value:p['id'] as int,child:Text('${p['name']} (${money(p['price'] as num)})'))).toList(),onChanged:(v){if(v!=null)setLocal(()=>selected=v);}),
        TextField(controller:qty,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:t('পরিমাণ','Quantity'))),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:Text(t('বাতিল','Cancel'))),FilledButton(onPressed:()async{
        final product=products.firstWhere((p)=>p['id']==selected); final q=int.tryParse(qty.text)??1;
        if(q<1)return;
        final total=(product['price'] as num).toDouble()*q;
        await ShopDb.instance.add('sales',{'total':total,'paid':total,'created_at':DateTime.now().toIso8601String()});
        await (await ShopDb.instance.database).update('products',{'stock':(product['stock'] as int)-q},where:'id=?',whereArgs:[selected]);
        if(ctx.mounted)Navigator.pop(ctx); await refresh();
      },child:Text(t('বিক্রি সংরক্ষণ','Save sale')))]
    )));
    qty.dispose();
  }
  Widget metric(String title, String value, IconData icon) => Card(child:Padding(padding:const EdgeInsets.all(16),child:Row(children:[Icon(icon,color:Theme.of(context).colorScheme.primary,size:28),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:Theme.of(context).textTheme.bodyMedium),Text(value,style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold))]))])));
  Widget home() => FutureBuilder<List<double>>(future:Future.wait([ShopDb.instance.sum('sales','total'),ShopDb.instance.sum('expenses','amount'),ShopDb.instance.sum('customers','due')]),builder:(ctx,s){
    if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final sales=s.data![0], expenses=s.data![1], due=s.data![2];
    return ListView(padding:const EdgeInsets.all(16),children:[
      Text(t('আজকের ব্যবসার সারাংশ','Business overview'),style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:10),metric(t('মোট বিক্রি','Total sales'),money(sales),Icons.point_of_sale),
      metric(t('মোট খরচ','Total expenses'),money(expenses),Icons.receipt_long),
      metric(t('ক্রেতার বাকি','Customer due'),money(due),Icons.people_alt),
      metric(t('আনুমানিক আয় (বিক্রি - খরচ)','Estimated balance (sales - expenses)'),money(sales-expenses),Icons.account_balance_wallet),
      const SizedBox(height:12),Text(t('দ্রুত কাজ','Quick actions'),style:Theme.of(context).textTheme.titleMedium),
      Wrap(spacing:8,runSpacing:8,children:[
        FilledButton.icon(onPressed:addSale,icon:const Icon(Icons.add_shopping_cart),label:Text(t('বিক্রি','Sale'))),
        OutlinedButton.icon(onPressed:addProduct,icon:const Icon(Icons.inventory_2),label:Text(t('পণ্য যোগ','Add product'))),
        OutlinedButton.icon(onPressed:addCustomer,icon:const Icon(Icons.person_add),label:Text(t('ক্রেতা যোগ','Add customer'))),
        OutlinedButton.icon(onPressed:addExpense,icon:const Icon(Icons.money_off),label:Text(t('খরচ যোগ','Add expense'))),
      ]),
      const SizedBox(height:12),Text(t('নোট: এটি প্রাথমিক সংস্করণ।','Note: This is an initial version.'),style:Theme.of(context).textTheme.bodySmall),
    ]);
  });
  Widget listPage(String table, String title, List<String> columns, List<String> keys) => FutureBuilder<List<Map<String,Object?>>>(future:ShopDb.instance.rows(table),builder:(ctx,s){
    if(!s.hasData)return const Center(child:CircularProgressIndicator());
    final rows=s.data!;
    return ListView(padding:const EdgeInsets.all(12),children:[
      Row(children:[Expanded(child:Text(title,style:Theme.of(context).textTheme.titleLarge)),IconButton(onPressed:table=='products'?addProduct:table=='customers'?addCustomer:addExpense,icon:const Icon(Icons.add_circle))]),
      if(rows.isEmpty)Padding(padding:const EdgeInsets.all(30),child:Center(child:Text(t('এখনো কোনো তথ্য নেই','No records yet')))),
      for(final r in rows) Card(child:ListTile(title:Text('${r[keys[0]]??''}'),subtitle:Text(columns.length>1?'${columns[1]}: ${r[keys[1]]??''}':''),trailing:keys.length>2?Text('${r[keys[2]]??''}'):null)),
    ]);
  });
  @override Widget build(BuildContext context) {
    final pages=[home(),listPage('products',t('পণ্যের তালিকা','Products'),[t('স্টক','Stock')],['name','stock','price']),listPage('customers',t('ক্রেতার তালিকা','Customers'),[t('ফোন','Phone'),t('বাকি','Due')],['name','phone','due']),listPage('expenses',t('খরচের তালিকা','Expenses'),[t('টাকা','Amount')],['title','amount'])];
    return Scaffold(appBar:AppBar(title:Text('Dokan Manager'),actions:[TextButton(onPressed:widget.onLanguage,child:Text(widget.english?'বাংলা':'English'))]),
      body:pages[tab],bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:[
        NavigationDestination(icon:const Icon(Icons.dashboard_outlined),label:t('ড্যাশবোর্ড','Home')),
        NavigationDestination(icon:const Icon(Icons.inventory_2_outlined),label:t('পণ্য','Products')),
        NavigationDestination(icon:const Icon(Icons.people_outline),label:t('ক্রেতা','Customers')),
        NavigationDestination(icon:const Icon(Icons.receipt_long_outlined),label:t('খরচ','Expenses')),
      ]));
  }
}
